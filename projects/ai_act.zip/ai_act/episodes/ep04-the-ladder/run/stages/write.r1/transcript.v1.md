---
episode: 4
title: The Ladder
defaults: { tone: measured, rate: normal }
---

## A car that can tell when it is being examined {tone: tense}

A test cell, somewhere in Europe. A car sits on a rolling road, front wheels turning, body going nowhere. There is a probe in the exhaust pipe. The steering wheel is dead straight, and it stays dead straight, because nobody is driving.

The test cycle is a fixed sequence. The same speeds, the same durations, in the same order, every time. That is what makes it a test.

The engine management software can read all of that. Wheel speed with no steering input. A rhythm of acceleration it has met before. Conditions inside a narrow band.

And when it recognises the pattern, it runs the emissions control system at full strength. Everything the car has, working properly.

Off the rig, on a road, with somebody actually steering, it backs that control off.

{pause: 1.4}

In 2015 this became public knowledge. Volkswagen. Roughly eight and a half million affected cars in Europe.

Now, the thing I am going to ask you to carry through the next half hour is not the deception. It is something much duller, and much more useful.

Nobody had to decide whether that car was inside the law.

It already was.

## Where this sits {tone: measured}

This is *The Instrument*, a series on the European Union's Artificial Intelligence Act — what it does, what it assumes, and whether any of it can be made to work. This is the fourth part.

You are holding two things from earlier. One: the definitional gate. Whether a piece of software is an *AI system* at all, which turns on whether it infers rather than merely applies rules a person wrote down. Two: the roles. Provider, deployer, and the fact that duties attach when a system is placed on the market or put into service, not when it starts hurting somebody.

Today the system is through the gate and somebody owns it. So the Act has to sort it. It has to decide how much law this particular thing attracts.

That sorting is done by one article and two annexes, and it is the most consequential piece of machinery in the whole Regulation. Get the sorting wrong and every obligation downstream lands on the wrong object.

The series holds its overall verdict until the end. What I will do today is take the sorting apart, and show you the one thing it cannot see.

## What the software was doing, in its own terms {tone: precise}

Back to the car, briefly, because the mechanism matters.

The engineering term for that arrangement is a *defeat device*, and it is the field's own word — it sits in European vehicle emissions law, in Article 5(2) of Regulation 715/2007, which is where such devices are prohibited. A defeat device is a piece of control software that detects the operating conditions characteristic of the approval test, and changes the emissions strategy accordingly.

One version of it — the version that later reached the European courts — ran the full exhaust-gas recirculation only between fifteen and thirty-three degrees Celsius, and only below a thousand metres. Outside that window, nitrogen oxides rose past the limits.

Now, a disclosure, and I would rather make it early than have you wonder. That software was not an AI system. It inferred nothing. It was a set of conditions somebody wrote down. And the AI Act did not exist in 2015, so nothing I say about it today is a claim that the Act applied.

What I am borrowing is not the software. It is the *route*. The road that car travelled to get to market is a road the AI Act now uses, and almost nobody talks about it.

## What the Act means by the word risk {tone: precise}

Before the ladder, one word has to be nailed down, because the whole structure rests on it.

When you hear *risk* in ordinary speech, you probably hear *danger*. A thing that might hurt you. That is not what the Regulation means, and the difference is load-bearing.

Article 3 gives sixty-eight definitions. The second of them reads — and these are the Act's words — quote, *risk means the combination of the probability of an occurrence of harm and the severity of that harm*, end of quote.

Two ingredients. How likely, and how bad.

Say it plainly: risk here is not a property of a thing. It is a product of two numbers. And that is precisely what makes it something you can *rate* — something you can put more of and less of on a scale.

You cannot build a ladder out of danger. You can build one out of a quantity.

## The first door {tone: quoting, rate: slow}

Article 6 of Regulation (EU) 2024/1689 is called *classification rules for high-risk AI systems*. I will give you its opening once, with the citation, and then I will stop reading numbers at you and call it the ladder.

Article 6, paragraph 1. An AI system is high-risk where both of two conditions are fulfilled. Quote: *the AI system is intended to be used as a safety component of a product, or the AI system is itself a product, covered by the Union harmonisation legislation listed in Annex I* — that is the first condition. And the second: *the product whose safety component pursuant to point (a) is the AI system, or the AI system itself as a product, is required to undergo a third-party conformity assessment*. End of quote.

{pause: 1.4}

Unpack that slowly, because it is written in the language of a field most listeners have never been inside.

Annex I is a list of existing European product laws. Not AI laws. Product laws, some of them decades old. It comes in two sections, and I am going to name three entries from the first and then stop, because reading a list aloud teaches nobody anything.

Toys. Lifts. Medical devices.

That is the flavour of it. Radio equipment is in there, and pressure equipment, and personal protective equipment. The second section holds the heavier sectoral regimes — rail interoperability, marine equipment, civil aviation, and the approval of motor vehicles.

So here is what Article 6, paragraph 1, actually says. If your AI system is a safety component of one of those products — or is one of those products — and that product already has to be checked by somebody other than the manufacturer before it can be sold, then your AI system is high-risk. Automatically. No further question.

And the word doing the work in that sentence is *safety component*.

Wrong reading: an important part. Right reading, from Article 3: a component that fulfils a safety function, or whose failure or malfunctioning endangers the health and safety of persons or property.

The 2026 amendment then sharpened it, and this is a limit you need alongside the rule. Systems used *solely* for convenience, efficiency, optimisation, automation or quality control expressly do not qualify as safety components. Unless — and the very next paragraph says this — unless their failure would endanger health and safety, in which case they do. There is also a carve-out for products that need third-party assessment only for reasons unrelated to health and safety, radio spectrum being the example the text gives.

So the first door is narrow, and it has a doorframe made of qualifiers. But it is a real door, and it is wide open for anything embedded in a regulated machine.

## The second door, and the shape of the ladder {tone: measured}

Paragraph 2 of the same article is one sentence long. In addition to the systems caught by paragraph 1, quote, *AI systems referred to in Annex III shall be considered to be high-risk*, end of quote.

Annex III is a different kind of list. Not products — *use cases*. Eight areas, each with sub-points. Biometrics. Critical infrastructure. Education. Employment. Access to essential services. Law enforcement. Migration and borders. The administration of justice and democratic processes.

Two doors.

And most people who have heard of this Act have only ever heard of the second one. They think high-risk means *on the Annex III list*. It does not. There is a whole parallel route in through the product legislation, and a car is on it — the approval and market surveillance of motor vehicles is Annex I, second section.

Which means that if that emissions strategy were an AI system today, the question of whether it was high-risk would never go near Annex III. Nobody would open the list. It would turn on whether an emissions-control strategy counts as a safety component — genuinely arguable, and I am not going to pretend to you that it is settled — and then the answer would arrive from the car law, not from the AI law.

{pause: 1.4}

Now, the ladder itself, which I want to build in front of you rather than recite.

The top rung forbids. Article 5 lists practices that may not be placed on the market, put into service or used at all, and it has been live since 2 February 2025. That rung is next episode's subject entirely.

Below it, the high-risk rung. Everything we are doing today. Duties, documentation, oversight, assessment — a heavy regime, and not yet in force. Annex III systems become high-risk on 2 December 2027. Annex I systems, on 2 August 2028.

Below that, a much lighter rung. Article 50 imposes specific transparency duties on certain systems — telling you that you are talking to a machine, marking synthetic content. Those have been live since 2 August 2026.

And below that, nothing. No rung. Most software in Europe sits there, and the Act has no opinion about it.

Three rungs impose duties. One forbids. That is the structure.

## What high-risk does not mean {tone: pointed}

Two corrections before we go further, because a technically-trained listener will arrive holding both mistakes.

The first is the four tiers. You will have seen a diagram: unacceptable, high, limited, minimal. A neat pyramid. The refutation first — the Regulation does not work that way. The operative text prohibits, classifies as high-risk, imposes transparency duties on certain systems, and is silent about the rest. Go looking in the provisions for a category called *limited risk* and you will not find it. The pyramid is a summary somebody made afterwards. It is not wrong as a picture. It is wrong as a place to look things up.

The second mistake is bigger, and it is the single most consequential wrong reading in the Act.

*High-risk* does not mean dangerous.

It is a legal classification. It is triggered by an Annex III listing, or by the Annex I product route, and it says nothing whatsoever about how harmful this particular deployment is to these particular people. A high-risk system can be harmless. A system on no list at all can wreck a life.

The label describes which body of law applies. Not how worried you should be.

## A model that sorted a queue {tone: somber}

Which brings me to the second instance, and this one is European, and it is not counterfactual about the harm.

From 2013 the Dutch Tax Administration — the Belastingdienst — ran a risk-classification model in its childcare-benefits division. Operationally, it was unremarkable. Supervised learning on applications that had previously been judged correct or incorrect, producing a risk score. The score was used as a first filter, so that officials scrutinised the highest-scoring claims first.

A triage tool. A way of ordering a queue.

Its inputs included dual nationality. They included low income. They included whether the applicant's name read as non-Dutch.

Between 2005 and 2019, roughly twenty-six thousand families — some estimates say thirty-five thousand — were wrongly accused of childcare-benefit fraud and required to repay in full. Commonly twenty to sixty thousand euros each. More than eleven hundred children were placed in foster care.

{pause: 1.4}

The third Rutte cabinet resigned in January 2021. On 25 May 2022 the Dutch government admitted that institutional racism, in part of the Tax Administration, was a root cause. Amnesty International's report on the affair is called *Xenophobic machines*.

One thing to keep straight, because secondary accounts blur it constantly. This is *not* SyRI. SyRI was a separate Dutch welfare-fraud system, struck down by the District Court of The Hague in February 2020. Different system, different case. The benefits scandal is the Tax Administration's risk-classification model, and that is what we are discussing.

So: we now have two systems in play. A car that recognised its examiner, which came in through the product door. And a scoring model in a tax office, which comes in through the other one.

## Point five, letter (a) {tone: quoting}

The benefits model is the cleanest match in the entire annex. Annex III, area five, point (a): quote, *AI systems intended to be used by public authorities or on behalf of public authorities to evaluate the eligibility of natural persons for essential public assistance benefits and services, including healthcare services, as well as to grant, reduce, revoke, or reclaim such benefits and services*, end of quote.

Evaluate eligibility. Grant, reduce, revoke, reclaim. A benefits risk model sits inside those words without any strain at all.

And notice the phrase that opens it: *intended to be used*.

That is the second load-bearing term of the day, and the Act defines it. *Intended purpose* means, quote, *the use for which an AI system is intended by the provider*, including the context and conditions of use, as specified in the instructions for use, in promotional or sales materials, and in the technical documentation. End of quote.

Read that again in plain words. The intended purpose is not what the thing gets used for. It is what the provider *says* it is for — in the manual, in the sales material, in the technical file.

Who gets to say what a system is for?

{pause: 1.4}

The person who wrote the documentation. Nobody else.

## The way off the list {tone: precise}

Now, being named in Annex III is not quite the end of it, and this is where the architecture gets interesting.

Paragraph 3 of Article 6 is a derogation. Wrong reading: an exemption you apply for, from somebody. There is no application and there is no somebody. It is a self-assessment, done by the provider, before the system goes on the market.

The test is written negatively, and that matters, so I will give it as it stands. By derogation, an Annex III system shall not be considered high-risk where, quote, *it does not pose a significant risk of harm to the health, safety or fundamental rights of natural persons, including by not materially influencing the outcome of decision making*, end of quote.

Not *does it influence*. Does it *not* influence. The system has to fail to matter.

That applies where one of four conditions is met — the system performs a narrow procedural task, or improves the result of a completed human activity, or detects patterns without replacing human assessment, or does preparatory work. Two of those four are enough to feel the shape; I will leave the others.

And then a carve-back, in its own sentence, which is the most important clause in the paragraph. Notwithstanding all of that — quote — *an AI system referred to in Annex III shall always be considered to be high-risk where the AI system performs profiling of natural persons*. End of quote.

Always. No derogation.

*Profiling* is the third term to earn, and the Act does not define it itself. It borrows the definition from data-protection law. In plain words — and this is my gloss, not the statute — it means using personal data automatically to evaluate things about a person.

A benefits risk model evaluates things about people, automatically, from their data. It profiles. The escape hatch is closed before it opens.

One more piece. A provider who *does* conclude their system is not high-risk has to document the assessment before placing it on the market, and register it anyway, under Article 49(2). You do not walk away quietly. You file.

## Change one fact {tone: curious}

The boundary of a rule only becomes audible when you move something. So let us move things.

**First.** Take that same model, lift it out of the tax office, and sell it to a bank to triage loan applications. Still high-risk? Yes — Annex III, area five, point (b): evaluating the creditworthiness of natural persons or establishing their credit score. Same annex, next letter. And that point carries its own limit, which you should hear alongside it: systems used for detecting financial fraud are excepted.

Now change one fact. The bank uses it to triage its *internal audit* workload. It ranks which of the bank's own files get reviewed this quarter. It touches no individual's application and no individual's outcome.

Is that still high-risk?

{pause: 1.4}

Possibly not. That looks like a narrow procedural task that does not materially influence the outcome of decision-making about anybody, and the derogation may take it off the ladder entirely. The software is identical. The classification moves, because what it is pointed at moved.

**Second.** Back to the benefits model, and take the number away. The system now outputs no score at all — just a ranked queue of case files, in order, with no figures attached.

The design document says it is a preparatory task. Triage. Ordering work.

The behaviour of the officials says something else, because the ones at the top of the list got treated as suspects. So does the system materially influence the outcome of decision-making? The answer depends on which evidence you look at, and the Act's test is applied by the provider, reading their own documentation.

**Third, and this is the one that should stay with you.** Remove nationality as a variable. Take it out completely. Keep postcode.

Postcode, in a segregated housing market, carries much of the same information. The discriminatory effect may barely move.

The classification under Article 6 does not move at all. Not a millimetre. It was high-risk before, because of what it is for and who uses it, and it is high-risk after, for exactly the same reason.

Blind.

The tier is not tracking the change that matters most. It was never built to.

## Why this shape and not another {tone: contemplative}

So why a ladder?

There were other shapes available, and they were not fringe ideas. One was a rights-based instrument — keyed not to what a product is, but to how severely it interferes with a protected interest, whoever caused it and whatever the technology. European data protection authorities pushed hard in that direction during the drafting, and I am leaving that argument alone today, because it is a whole episode of its own and it deserves the room.

The other was sectoral. Rules for medicine written by the people who regulate medicine. Rules for policing written by the people who regulate policing. Rules for credit written by financial supervisors. The Commission's own impact assessment of April 2021 set out a sectoral, ad-hoc approach as one of the options on the table, considered it, and did not take it.

The tier model won for two reasons that are worth saying out loud, because they are good reasons.

First, it is the shape European product law already had. Conformity assessment, declarations, marking, market surveillance — that apparatus exists, it has staff, and it reaches every unit placed on the market before anyone is hurt.

Second, it gives industry an answer in advance. Read the list, find yourself or fail to, know your obligations. That is worth a great deal to somebody trying to build something.

And what was traded away is this. The tier is fixed by intended purpose, at design time, by the provider. Harm is contextual, and it turns up in deployment.

## What the rule assumes about the machine {tone: pointed}

That trade is the heart of this episode, so let me put it as directly as I can.

Article 6 presumes a system with a stable intended purpose, declared by the person who built it. It presumes that you can read risk off what a thing was built for.

The benefits model was built to sort a queue. That is a true and accurate description of it. Any technical file would have said so honestly.

It was *used* as proof of fraud.

The tier tracked the design document. The harm tracked the organisation. And nothing in Article 6 can see the gap between those two, because Article 6 only ever reads one of them.

Now push down through that, because "the model was biased" is where most accounts stop and it is the least interesting layer.

Technically: a classifier whose training labels came from prior investigations. It did not learn which applications were wrong. It learned which applications had previously been *found* wrong — which is a record of where officials had already been looking.

Organisationally: a score read as evidence, by people who had not been trained to read it, with no explanation attached and no path to appeal.

Institutionally: a tax authority with a fraud mandate and no correction mechanism. Economically: recovery targets. And underneath all of it, discrimination on nationality, and a decade before anyone in government said the words institutional racism out loud.

The ladder reaches the first of those layers. It touches the second — there are real duties on the organisation using a system, and we will spend proper time on them. It does not reach the rest at all.

I am not going to tell you today whether that is a fatal objection to the design. I am telling you where the instrument stops.

## Where this is contested {tone: measured}

Three joints, and they are in different conditions.

Is a tiered risk model the right shape in the first place? Contested — and I have no consensus to report you, because informed opinion genuinely has not converged. There are serious people who think tiers are the only administrable thing and serious people who think tiers misdescribe the problem. The weight does not lean here. What I can name are the two rival shapes, and I have: rights-based, and sectoral.

Does paragraph 3 open an escape hatch that providers will self-certify their way through? Also contested — and the profiling carve-back is both the limit on that worry and the test of it. Anything that profiles cannot use the hatch. Whether providers agree with the regulator about what profiling means is a question nobody can answer yet, because nobody has litigated it.

And is Annex III a list that can be kept current, or one that will always be a scandal behind? Still moving. The Commission can amend the annex by delegated act, without reopening the statute — that power sits in Article 7. It can also add to or modify the derogation conditions, and delete them where deletion is needed to maintain protection, with an express floor: no such amendment may decrease the overall level of protection.

Contrast that with Annex I. Moving something there took an actual amendment to the Regulation, in 2026 — the machinery legislation was taken out of the first section and now appears at the end of the second.

One annex bends. The other has to be legislated.

## As written, as enforced {tone: somber}

Now the uncomfortable arithmetic.

None of this applied to the Dutch Tax Administration. Not one word of it. The Act did not exist.

And the parts that would apply to its successors — the ones that make a benefits risk model high-risk and load it with duties — do not apply until 2 December 2027.

What actually ended that affair was a parliamentary inquiry, sustained journalism, and a cabinet resigning. No market-surveillance authority. No conformity assessment. No classification.

I said at the start that I would name what I am leaving out, so: the entire machinery behind the first door. Annex I's two sections, and the reason the split matters — because for products in the second section, most of the AI Act's own requirements do not apply directly at all. The duties get threaded into the existing sectoral law by Articles 102 to 110, which have been in application since 27 July 2026, and which are plumbing.

I have just summarised a whole parallel route into the high-risk regime in about ninety seconds. That is a compression and I would rather admit it than disguise it. The machinery gets taken apart properly later in the series.

## What you now ask {tone: measured}

So what do you take away, other than a list of article numbers you will not remember and should not try to?

Three questions, and they work on any system, in any jurisdiction, under any regime.

The first. Which rung is this thing on — and was that decided by what it is *for*, or by what it *does* to someone? Almost every classification scheme you will meet answers the first and quietly claims to have answered the second.

The second. Who declared the purpose, and would the people actually using this system recognise the description? Go and read the technical file, then go and watch the room. If those two accounts have drifted apart, ask whether anything in the rule is capable of noticing.

And the third, which is the benefits model in one line. Does this system decide, or does it produce a queue that somebody else treats as a decision? Because the law will look at the first and the harm will come from the second.

{pause: 1.4}

We have a ladder now. Three rungs that impose duties, and one that forbids.

Next time, the top rung. Why a legal order whose whole instinct is to regulate rather than ban decided that a small number of things may not be built at all.