---
episode: 2
title: The Pacing Problem
defaults:
  tone: measured
  rate: normal
---

## Two men, in print, three years apart {tone: measured}

In 1996 an American appeals judge published a short essay in a law journal, and the title was a joke. Frank Easterbrook called it "Cyberspace and the Law of the Horse." It ran in the University of Chicago Legal Forum.

The joke was aimed at a room. Easterbrook had been invited to speak at a conference about the law of cyberspace, and what he told that conference was that there was no such subject.

His argument went through a horse. Suppose you set out to teach the law of the horse. You collect every case that ever involved one. People kicked by horses. People who bought a horse that turned out to be lame. People who insured horses, raced horses, left a horse to a nephew in a will. You now have a very large pile of cases and no subject. What you actually have is tort law, and contract law, and property law, wearing a horse costume. The pile teaches you less than the underlying law would have taught you on its own.

Cyberspace, he said, is a horse.

Three years later, Lawrence Lessig answered him in the Harvard Law Review, and borrowed Easterbrook's title to do it: "The Law of the Horse: What Cyberlaw Might Teach." Lessig's reply was not that Easterbrook had been unkind to a conference. It was that Easterbrook had missed what the new subject makes visible — and I will come back to what he thought it makes visible, because it turns out to be the most useful idea in this episode.

{pause: 1.4}

That is a real disagreement. Two named people, both of whom knew the field, in print, on the record, about whether you should ever write a statute named after a technology.

Europe has now answered that question, at length, in eighty-odd pages of operative text.

## What this episode is, and what it is not {tone: lucid}

This is The Instrument. In the first episode we built the gate: what makes a thing an AI system in the first place, and the moment at which anybody's duty begins.

Today there is no statute. No article numbers you have to hold, no quoted text, no test to apply. This episode hands you a criterion instead — a way of judging whether an instrument was written at the right moment, and whether it can survive the thing it was written about.

You will use it three times. When we get to the ladder of risk, in Episode 4, the whole architecture turns out to rest on a bet made at design time. When we get to standards, in Episode 8, the law moves its own deadlines to fit a document that private bodies had not finished. And in Episode 9, when a model counts as dangerous above a particular quantity of arithmetic, that line is drawn exactly where the technology stood in the year somebody drew it.

You do not need to remember those numbers. They will announce themselves. What you want out of today is the question, not the appointments.

## Nineteen months {tone: pointed}

Here is the fact this whole argument sits on, and it is a small one.

On the twenty-first of April 2021, the European Commission published its proposal for the Artificial Intelligence Act. That document has a name and a number — COM(2021) 206 final — and I will say it once and then stop. In that proposal, the way you told whether something was an AI system was by looking it up. There was a list, in an annex, of techniques and approaches. Machine learning. Logic and knowledge-based approaches. Statistical methods. If your system used one of the things on the list, you were in.

Now. Episode 1 gave you the definition that was actually adopted. Take a second with it.

{pause: 1.4}

Does that definition name a single technique?

{pause: 1.4}

It does not. The adopted definition asks what the system *does* — whether it infers — and says nothing about how. Somewhere between the proposal and the Act, the list went away.

Something else happened in that window. ChatGPT was released to the public on the thirtieth of November 2022. Nineteen months after the proposal.

And the chapter of the Act that governs general-purpose models — the one that eventually runs from Article 51 to Article 56, the compute threshold, the code of practice, the whole apparatus for a model that is not built for any particular job — is not in the April 2021 text. At all. It does not exist there.

## The reading I am going to refuse {tone: precise}

There is an obvious thing to say about that, and it is wrong, so let me say it and then take it away.

The obvious thing is: the law was already out of date before it passed. Brussels spent years drafting a regulation for the technology of 2021 and shipped it into the world of 2023. Too slow. Always too slow.

But look at what actually happened in those nineteen months. The list went away. The general-purpose chapter got written. The definition was rebuilt around what a system does rather than what it is made of. The drafters noticed, and they changed the instrument while it was still in their hands.

So the nineteen months are not evidence that the law cannot keep up. They are evidence of something more interesting and more awkward: the instrument was a moving object right up until the moment it stopped moving. And the question worth asking is not whether law is slow. It is this — *was this rule drawn where the technology is, or where it was when somebody started drafting?* That is a question you can put to any instrument, and it has a different answer every time.

Four people have four different views about what follows from that. They all have names and they are all in print.

## The refusal, at its strongest {tone: measured}

Start with Easterbrook, because his is the position most people skip.

He is not saying technology is unimportant. He is saying that a statute named after a technology carries three defects, and they compound.

It dates. The name on the front of the law is a snapshot of what people were worried about in the drafting year, and technologies do not hold still for their portrait.

It entrenches. Whoever is already large when the rule is written has the lawyers to shape it and the compliance budget to absorb it. A newcomer has neither.

And it is unnecessary, because you already have law. Somebody was misled: that is contract, or consumer protection. Somebody was injured: that is tort. Somebody was discriminated against: that is discrimination law, which has existed for decades and does not care whether the discriminating was done by a person, a spreadsheet or a neural network.

Take Easterbrook seriously and you get a very specific world. No gate. No risk tiers. No CE mark on a piece of software. No conformity assessment, no notified bodies, no technical documentation. And, crucially, no duty on anything at all until it has hurt somebody — because the ordinary law he trusts is law that arrives after the harm, through a court, brought by the person harmed.

That is the cost. It is worth holding in mind, because for the rest of this series we are going to be examining a machine that exists precisely to attach duties before anyone is hurt. Easterbrook's answer is that this is not worth what it costs.

## Lessig's answer, and the idea underneath it {tone: curious}

Lessig's reply, in 1999, was that studying the new thing teaches you something general — and the thing it teaches is about where constraint actually comes from.

His claim is easier to feel than to state. A rule tells you what you may do. But most of what you actually do is decided by what is *possible*, and what is possible is decided by whoever built the room you are standing in. A door that does not open is a more effective rule than a sign saying do not enter. On a network, the door is the software. Lessig's book from the same year — *Code and Other Laws of Cyberspace*, later rewritten as *Code: Version 2.0* — is four hundred pages of that observation.

The year before Lessig's book, a law professor named Joel Reidenberg had published the same structural point under a name of his own: "Lex Informatica," in the Texas Law Review. Technical capability, he argued, sets rules that behave like law — they apply to everyone, they are enforced automatically, and nobody voted for them.

So: regulation by architecture. If you want that phrase to do work, do not hear it as "code is law," which is a slogan. Hear it as a drafting instruction. It says that if you are a regulator and you want effect, you should specify the built environment rather than the conduct, because the built environment enforces itself and conduct rules do not.

Both of them, Lessig and Reidenberg, were answering the 1990s belief that the internet was inherently ungovernable. Their answer was that it was already governed, just not by anyone you elected.

And the European AI Act is full of this. It is full of it in places where it never says the word. The duty to make a high-risk system generate its own logs. The duty to mark synthetic content in a way a machine can read. The requirement that technical documentation exist before the thing is sold. None of those regulate a decision. All of them regulate a structure, so that later, when somebody asks a question, the structure has already answered it.

So far we have two positions. Easterbrook: do not write the statute, use the law you have. Lessig and Reidenberg: if you write it, write it into the architecture, because that is where the constraint lives anyway.

Neither of those is about timing. The next two are.

## Collingridge {tone: contemplative}

In 1980 a British scholar named David Collingridge published a book called *The Social Control of Technology*, and it contains a trap that nobody has got out of since.

Controlling a technology, he argued, fails in one of two ways, and there is no third option.

Early, while the technology is small and pliable and you could still steer it — you do not know what to steer away from. Nobody has been harmed yet. The harms are not visible because they have not happened.

Late, once the harms are obvious and documented and you know exactly what you would like to change — the technology is embedded. There are factories, supply chains, jobs, standards, trained professionals, sunk capital and a lobby. Change is now slow, expensive and contested.

Knowledge arrives on one schedule. Power to act expires on another. They do not overlap.

That is the Collingridge dilemma, and it is the reason regulation always feels either premature or too late, because structurally it is one or the other. He was writing against a live backdrop: chemicals, nuclear power, asbestos. Regimes that arrived after the harm was demonstrated and the industry was established.

Now — what would you build if you believed that?

{pause: 1.4}

You would build an instrument that assumes it is wrong. You would write the rule early, because early is when you can, and then you would install inside the rule a power to change the rule once you have learned something. Not a new statute every time. A mechanism.

The Act has three of those, and I will name them once as destinations rather than teach them: a power to amend the list of high-risk uses, a general power to adopt delegated acts, and a standing duty to evaluate and review the Regulation on a clock. Whether or not anybody in Brussels said Collingridge's name, those three articles are a Collingridge answer.

## The pacing problem {tone: measured}

The fourth position has a name you already half-believe, which is why it needs handling carefully.

You have heard some version of this: technology moves fast, and the law is slow. Said that way it is a complaint, and complaints are not claims.

Made properly, it is a claim, and it is specific. Larry Downes put it in a book called *The Laws of Disruption*, in 2009, in a sentence he is known for: technology changes exponentially, but social, economic and legal systems change incrementally. Two different rates of change. Not one slow thing and one fast thing — two curves of different shape, which means the gap between them does not close. It widens.

In 2011 that claim got a book of its own, edited by Gary Marchant, Braden Allenby and Joseph Herkert, and the book is where the phrase settled: *The Growing Gap Between Emerging Technologies and Legal-Ethical Oversight: The Pacing Problem*.

The policy conclusion is the part that matters, and it is the opposite of Collingridge's. If institutions cannot keep pace, then do not write anything precise enough to be overtaken. Prefer principles to rules. Prefer a regulator with discretion to a number in a statute. A threshold is obsolete the moment the technology walks past it, and then you are enforcing an old opinion about a new machine.

So now hold both. Collingridge says: regulate early, and expect to be wrong. The pacing problem says: never write anything a technology can outrun.

If you had to build one instrument that satisfied both of those at the same time — what would it have to contain?

{pause: 1.4}

## Both {tone: pointed}

It would have to contain a number, and a power to change the number.

Which is exactly what the Act does. There is a point in the general-purpose chapter where a model is presumed to be dangerous once the computation used to train it crosses a stated quantity. A hard line, in the text, checkable by anyone with the training logs. That is the Collingridge move: commit early, in public, to something specific.

And one paragraph later, the Commission is given power to move that number. Not by passing a new Act. By a mechanism inside this one.

The figure itself belongs to a later episode and you can safely forget it today. The shape is what I want you to keep. A threshold, plus a lever attached to the threshold. Regulate early and expect to be wrong, and build in the apparatus for being wrong.

That is the second time I have put this to you and it is the centre of the episode, so let me say it once more, plainly. Every instrument is written at a moment. The two questions worth asking of any of them are: was this drawn where the technology is, or where it was when drafting began — and what can this instrument change about itself without going back to the legislature, and who holds that power?

## The objection to my own answer {tone: precise}

I find the Collingridge framing the most useful of the four, and the Act's response to it — commit early, install the levers — the right instinct. So let me put the strongest thing against it before I go any further, because it is strong.

A power to amend is not a mechanism. It is a promise about future political will.

A lever only moves if somebody pulls it, and the people who would have to pull it are the same people who were lobbied about the original number. A statute that can adjust itself is a statute that can be adjusted by whoever has the best access. And there is a sharper version still: flexibility built in to keep a rule current can just as easily be used to keep a rule *away*.

Which is, on the record, roughly what happened. The Act was amended in 2026, and the most consequential thing the amendment did was move dates. The high-risk regime — the heavy one, the one this series spends most of its time inside — was pushed back to the second of December 2027. The instrument used its own flexibility, and it used it to postpone.

Whether that is Collingridge working as designed, or Collingridge being quietly abandoned, is not settled and I am not going to pretend it is. It is still moving, and December 2027 is the date on which we find out.

## The awkward part {tone: pointed}

One more thing about the pacing problem, and it is the thing that usually goes unsaid.

Two readings are available, and I want you to pick before I answer.

The first: it is an analytic claim about institutions — two rates of change, a widening gap, a real problem for anyone designing a rule.

The second: it is a lever. "This moves too fast to regulate" is, and has always been, the most useful sentence available to anyone who would prefer not to be regulated. It does not require you to defend any particular practice. It simply relocates the whole argument to a discussion of legislative speed.

{pause: 1.4}

The answer is both, and the same sentence does both jobs, which is exactly what makes it hard to handle.

Both sides of this have holders with names. In 2023, William Aspray and Philip Doty published a paper in the Journal of the Association for Information Science and Technology asking, in the title, whether technology really does outpace policy and whether it matters. The value of that paper for our purposes is its posture: it treats the outpacing claim as something to be examined rather than assumed. That is rarer than it sounds.

On the other side, in good faith, Adam Thierer of the Mercatus Center has written for years on the pacing problem, on Collingridge, and on what he calls permissionless innovation — the position that the default should be permission to build, with the burden on whoever wants to stop you.

I am not going to tell you the weight of opinion leans one way here, because I do not think it does. What I will tell you is the move that keeps you honest, which is to refuse both of the easy ones. Do not accept the pacing claim wholesale, because a claim that proves every regulation premature has proved nothing. And do not dismiss it as industry noise either, because Collingridge was not in industry and neither were Marchant, Allenby or Herkert, and the gap they describe is real.

Take it seriously and ask who is saying it.

## Where it stands {tone: lucid}

Three things, and then I am done.

Easterbrook against Lessig is settled as a matter of what got built, and unsettled as a matter of argument. Europe wrote the statute named after the technology. That does not mean Easterbrook was wrong about what it would cost — it means the cost was paid, and this series is partly an audit of what was bought with it.

Collingridge against the pacing problem is genuinely contested, and the Act refuses to choose, and its refusal is the fixed threshold with the movable lever.

And whether staged application actually solves the dilemma, or only defers it, is still moving. That one has a test date on it.

## What you take with you {tone: measured}

Two questions, and you will use both of them long after you have forgotten every name in this episode.

The first. When you meet a rule — any rule, about anything technical — ask whether it was drawn where the technology is, or where the technology was when somebody started drafting. The gap between those two is usually years, and it is usually invisible on the page.

The second. Ask what this instrument can change about itself without anyone reopening the statute — and who holds that power. Every serious modern regulation has such a mechanism. The interesting question is never whether it exists. It is who gets to pull it, and what they have used it for so far.

And a third, smaller and sharper, which you should keep somewhere less comfortable. When somebody tells you a thing moves too fast to be regulated, ask who benefits from that being true.

{pause: 1.4}

Next time we go back inside the text.

Because if you are going to regulate anyway — and Europe has — then before anything else you have to say who is responsible. The Act has an answer to that, and it is a narrower answer than most organisations expect. An airline once stood up in a tribunal and argued for a third option that the law does not contain.

It did not go well.